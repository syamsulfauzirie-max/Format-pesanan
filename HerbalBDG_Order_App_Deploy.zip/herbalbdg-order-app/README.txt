HERBAL.BDG Order Form - Deployment

1. Deploy this folder to a static host (Netlify Drop or GitHub Pages).
2. The entry file is index.html.
3. WhatsApp admin destination is configured in the page: 62895340588012.
4. Shipping is confirmed by admin after the order arrives in WhatsApp.
5. This is a static order form. It does not store customer data in a database.
